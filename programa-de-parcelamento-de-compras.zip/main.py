print('{:=^40}'.format('Lojas Minerva'))
preço = float(input('Preço das compras: R$'))
print('''Formas de Pagamento
[1] à vista dinheiro/cartão
[2] à vista no cartão
[3] 2X no cartão
[4] 3X no cartão''')
opção = int(input('Qual é a opção'))
if opção == 1:
    total = preço - (preço * 10 / 100)
elif opção == 2:
    total = preço - (preço * 5 / 100)
elif opção == 3:
    total = preço
    parcela = total / 2
    print('Sua compra será parcelada em  2X de R${:.2f} sem juros'.format(parcela))   
elif opção == 4:
    total = preço + (preço * 20 / 100)
    totparc = int(input('Quantas parcelas?'))
    parcela = total / totparc
    print('Sua compra será  parcelada em {}x de R${:.2f} com juros'.format(totparc, parcela))
else:
    total = 0
    print('Opção Inválida de pagamento. Tente novamente!')
print('Sua compra de R${:.2f} vai custar R${:.2f} no final'.format(preço, total))

    
