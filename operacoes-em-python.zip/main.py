a = 7
b = 5
soma = a+b
quadrado = soma**2
print('A soma é:',soma,'O quadrado da soma é:',quadrado)
if quadrado == 144
    print('O quadrado é 144!')
else:
    print('O quadrado não é 144!')